﻿using MvcCoreProjMehedi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MvcCoreProjMehedi.ViewModels
{
    public class SchoolViewModels
    {
        public IEnumerable<StudentTbl> Students { get; set; }
        public IEnumerable<ClassTbl> Classes { get; set; }
    }
}
