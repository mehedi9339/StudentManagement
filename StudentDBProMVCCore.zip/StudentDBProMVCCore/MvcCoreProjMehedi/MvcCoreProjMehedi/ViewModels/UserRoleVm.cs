﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace MvcCoreProjMehedi.ViewModels
{
    public class UserRoleVm
    {
        [Key]
        public string Username { get; set; }
        public string Role { get; set; }
    }
}
