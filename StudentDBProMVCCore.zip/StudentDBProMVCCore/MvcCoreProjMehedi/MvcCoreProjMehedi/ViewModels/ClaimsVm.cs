﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MvcCoreProjMehedi.ViewModels
{
    public class ClaimsVm
    {
        public ClaimsVm()
        {
            UserClaimsVm = new List<UserClaimsVm>();
        }
        public string Email { get; set; }
        public List<UserClaimsVm> UserClaimsVm { get; set; }
    }
}
