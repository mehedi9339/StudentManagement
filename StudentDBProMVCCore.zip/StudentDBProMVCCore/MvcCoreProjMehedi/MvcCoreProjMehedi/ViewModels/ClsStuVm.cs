﻿using MvcCoreProjMehedi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MvcCoreProjMehedi.ViewModels
{
    public class ClsStuVm
    {
        public string ClassName { get; set; }
        public int RoomNo { get; set; }
        public IList<StudentTbl> StudentTbls { get; set; }
    }
}
