﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using MvcCoreProjMehedi.Data;
using MvcCoreProjMehedi.Models;

namespace MvcCoreProjMehedi.Controllers
{
    public class StudentTblsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IHostingEnvironment _Hostcontext;
        public StudentTblsController(ApplicationDbContext context, IHostingEnvironment hosting)
        {
            _context = context;
            _Hostcontext = hosting;
        }

        // GET: StudentTbls
        public async Task<IActionResult> Index(string searchString, string sortOrder, string currentFilter, int? pageNumber)
        {
            ViewData["CurrentSort"] = sortOrder;
            ViewData["NameSortParam"] = String.IsNullOrEmpty(sortOrder) ? "name_desc" : "";
            ViewData["CurrentFilter"] = searchString;
            if (searchString != null)
            {
                pageNumber = 1;
            }
            else
            {
                searchString = currentFilter;
            }
            ViewBag.CurrentFilter = searchString;

            var studentTbls = from m in _context.StudentTbls
                                select m;
            if (!string.IsNullOrEmpty(searchString))
            {
                studentTbls = studentTbls.Where(s => s.StudentName.Contains(searchString));
            }

            switch (sortOrder)
            {
                case "name_desc":
                    studentTbls = studentTbls.OrderByDescending(s => s.StudentName);
                    break;
                default:
                    studentTbls = studentTbls.OrderBy(s => s.StudentName);
                    break;
            }
            int pageSize = 3;




            var applicationDbContext = _context.StudentTbls.Include(s => s.ClassTbl).Include(s => s.SectionTbl);
            return View(await PaginatedList<StudentTbl>.CreateAsync(studentTbls.AsNoTracking(), pageNumber ?? 1, pageSize));
            //return View(await applicationDbContext.ToListAsync());
        }

        // GET: StudentTbls/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var studentTbl = await _context.StudentTbls
                .Include(s => s.ClassTbl)
                .Include(s => s.SectionTbl)
                .FirstOrDefaultAsync(m => m.StudentId == id);
            if (studentTbl == null)
            {
                return NotFound();
            }

            return View(studentTbl);
        }
        [Authorize]
        // GET: StudentTbls/Create
        public IActionResult Create()
        {
            ViewData["ClassId"] = new SelectList(_context.ClassTbls, "ClassId", "ClassName");
            ViewData["SecId"] = new SelectList(_context.SectionTbls, "SecId", "SectionName");
            return View();
        }

        // POST: StudentTbls/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(StudentTbl studentTbl)
        {
            if (ModelState.IsValid)
            {
                string ext = Path.GetExtension(studentTbl.ImgFile.FileName).ToLower();
                if (ext == ".jpg" || ext == ".jpeg" || ext == ".png")
                {
                    string fileName = Path.GetFileNameWithoutExtension(studentTbl.ImgFile.FileName);
                    string file = "_" + fileName + ext;
                    var filePath = Path.Combine(_Hostcontext.WebRootPath, "images\\img", file);
                    using (var fileStream = new FileStream(filePath, FileMode.Create))
                    {
                        studentTbl.ImgFile.CopyTo(fileStream);
                        studentTbl.Photo = "\\images\\img\\" + file;
                    }

                }
                _context.Add(studentTbl);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            ViewData["ClassId"] = new SelectList(_context.ClassTbls, "ClassId", "ClassId", studentTbl.ClassId);
            ViewData["SecId"] = new SelectList(_context.SectionTbls, "SecId", "SecId", studentTbl.SecId);
            return View(studentTbl);
        }
        [Authorize]
        // GET: StudentTbls/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var studentTbl = await _context.StudentTbls.FindAsync(id);
            if (studentTbl == null)
            {
                return NotFound();
            }
            ViewData["ClassId"] = new SelectList(_context.ClassTbls, "ClassId", "ClassId", studentTbl.ClassId);
            ViewData["SecId"] = new SelectList(_context.SectionTbls, "SecId", "SecId", studentTbl.SecId);
            return View(studentTbl);
        }

        // POST: StudentTbls/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, StudentTbl studentTbl)
        {
            if (id != studentTbl.StudentId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    string ext = Path.GetExtension(studentTbl.ImgFile.FileName).ToLower();
                    if (ext == ".jpg" || ext == ".jpeg" || ext == ".png")
                    {
                        string fileName = Path.GetFileNameWithoutExtension(studentTbl.ImgFile.FileName);
                        string file = "_" + fileName + ext;
                        var filePath = Path.Combine(_Hostcontext.WebRootPath, "images\\img", file);
                        using (var fileStream = new FileStream(filePath, FileMode.Create))
                        {
                            studentTbl.ImgFile.CopyTo(fileStream);
                            studentTbl.Photo = "\\images\\img\\" + file;
                        }

                    }
                    _context.Entry(studentTbl).State = EntityState.Modified;
                    _context.SaveChanges();
                    return RedirectToAction(nameof(Index));
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!StudentTblExists(studentTbl.StudentId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["ClassId"] = new SelectList(_context.ClassTbls, "ClassId", "ClassId", studentTbl.ClassId);
            ViewData["SecId"] = new SelectList(_context.SectionTbls, "SecId", "SecId", studentTbl.SecId);
            return View(studentTbl);
        }
        [Authorize]
        // GET: StudentTbls/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var studentTbl = await _context.StudentTbls
                .Include(s => s.ClassTbl)
                .Include(s => s.SectionTbl)
                .FirstOrDefaultAsync(m => m.StudentId == id);
            if (studentTbl == null)
            {
                return NotFound();
            }

            return View(studentTbl);
        }

        // POST: StudentTbls/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var studentTbl = await _context.StudentTbls.FindAsync(id);
            _context.StudentTbls.Remove(studentTbl);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool StudentTblExists(int id)
        {
            return _context.StudentTbls.Any(e => e.StudentId == id);
        }
    }
}
