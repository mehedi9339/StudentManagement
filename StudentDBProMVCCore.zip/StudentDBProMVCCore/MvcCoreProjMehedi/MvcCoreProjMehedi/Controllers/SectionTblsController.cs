﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using MvcCoreProjMehedi.Data;
using MvcCoreProjMehedi.Models;

namespace MvcCoreProjMehedi.Controllers
{
    public class SectionTblsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public SectionTblsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: SectionTbls
        public async Task<IActionResult> Index()
        {
            return View(await _context.SectionTbls.ToListAsync());
        }

        // GET: SectionTbls/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var sectionTbl = await _context.SectionTbls
                .FirstOrDefaultAsync(m => m.SecId == id);
            if (sectionTbl == null)
            {
                return NotFound();
            }

            return View(sectionTbl);
        }
        [Authorize]
        // GET: SectionTbls/Create
        public IActionResult Create()
        {
            return View();
        }
        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("SecId,SectionName,Description")] SectionTbl sectionTbl)
        {
            if (ModelState.IsValid)
            {
                _context.Add(sectionTbl);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(sectionTbl);
        }
        [Authorize]
        // GET: SectionTbls/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var sectionTbl = await _context.SectionTbls.FindAsync(id);
            if (sectionTbl == null)
            {
                return NotFound();
            }
            return View(sectionTbl);
        }
        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("SecId,SectionName,Description")] SectionTbl sectionTbl)
        {
            if (id != sectionTbl.SecId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(sectionTbl);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!SectionTblExists(sectionTbl.SecId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(sectionTbl);
        }
        [Authorize]
        // GET: SectionTbls/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var sectionTbl = await _context.SectionTbls
                .FirstOrDefaultAsync(m => m.SecId == id);
            if (sectionTbl == null)
            {
                return NotFound();
            }

            return View(sectionTbl);
        }

        // POST: SectionTbls/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var sectionTbl = await _context.SectionTbls.FindAsync(id);
            _context.SectionTbls.Remove(sectionTbl);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool SectionTblExists(int id)
        {
            return _context.SectionTbls.Any(e => e.SecId == id);
        }
    }
}
