﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using MvcCoreProjMehedi.Data;
using MvcCoreProjMehedi.Models;
using MvcCoreProjMehedi.ViewModels;

namespace MvcCoreProjMehedi.Controllers
{
    public class TeacherTblsController : Controller
    {
        private ApplicationDbContext _db { get; set; }
        private readonly IHostingEnvironment _hosting;
        public TeacherTblsController(ApplicationDbContext db, IHostingEnvironment hosting)
        {
            this._db = db;
            this._hosting = hosting;
        }
        public IActionResult Index()
        {
            return View();
        }
        public JsonResult Get()
        {
            var data = _db.TeacherTbls.ToList();
            return Json(data);
        }
        [HttpPost]
        public IActionResult AddTeacher(TeacherVm vm, IEnumerable<IFormFile> files)
        {
            if (ModelState.IsValid)
            {
                string uploadPath = Path.Combine(_hosting.WebRootPath, "Images");
                TeacherTbl teacher = new TeacherTbl
                {
                    TeacherName = vm.TeacherName,
                    TeacherAddress = vm.TeacherAddress,
                    TeacherPhone = vm.TeacherPhone,
                    TeacherEmail = vm.TeacherEmail,
                    JoiningDate = vm.JoiningDate,
                    SecId = vm.SecId,
                    ClassId = vm.ClassId
                };
                foreach (var file in files)
                {
                    if (file != null && file.Length > 0)
                    {
                        var fileName = Guid.NewGuid().ToString() + file.FileName;
                        using (var s = new FileStream(Path.Combine(uploadPath, fileName), FileMode.Create))
                        {
                            file.CopyTo(s);
                            teacher.Photo = "/Images/" + fileName;
                        }
                    }
                }
                _db.TeacherTbls.Add(teacher);
            }
            if (_db.SaveChanges() > 0)
            {
                return Json(new { result = "Success" });
            }
            else
            {
                return Json(new { result = "Failed" });
            }
        }
        public JsonResult GetById(int id)
        {
            var teacher = _db.TeacherTbls.Find(id);
            return Json(teacher);
        }
        public JsonResult Delete(int id)
        {
            var teacher = _db.TeacherTbls.Find(id);
            _db.TeacherTbls.Remove(teacher);
            if (_db.SaveChanges() > 0)
            {
                return Json(new { result = "Successfully Deleted" });
            }
            return Json(new { result = "Delete Failed" });
        }
        [HttpPost]
        public IActionResult UpdateTeacher(TeacherVm vm, IEnumerable<IFormFile> files)
        {
            if (ModelState.IsValid)
            {
                string uploadPath = Path.Combine(_hosting.WebRootPath, "Images");
                TeacherTbl teacher = new TeacherTbl
                {
                    TeacherName = vm.TeacherName,
                    TeacherAddress = vm.TeacherAddress,
                    TeacherPhone = vm.TeacherPhone,
                    TeacherEmail = vm.TeacherEmail,
                    JoiningDate = vm.JoiningDate,
                    SecId = vm.SecId,
                    ClassId = vm.ClassId,
                    TeacherId = vm.TeacherId,
                    Photo = vm.Photo
                };
                foreach (var file in files)
                {
                    if (file != null && file.Length > 0)
                    {
                        var fileName = Guid.NewGuid().ToString() + file.FileName;
                        using (var s = new FileStream(Path.Combine(uploadPath, fileName), FileMode.Create))
                        {
                            file.CopyTo(s);
                            teacher.Photo = "/Images/" + fileName;
                        }
                    }
                }
                _db.Entry(teacher).State = EntityState.Modified;
            }
            if (_db.SaveChanges() > 0)
            {
                return Json(new { result = "Success" });
            }
            else
            {
                return Json(new { result = "Failed" });
            }
        }
    }
}