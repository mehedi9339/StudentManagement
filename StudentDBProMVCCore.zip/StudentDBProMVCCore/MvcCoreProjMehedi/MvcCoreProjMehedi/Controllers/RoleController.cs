﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using MvcCoreProjMehedi.Models.Identity;
using MvcCoreProjMehedi.ViewModels;

namespace MvcCoreProjMehedi.Controllers
{
    public class RoleController : Controller
    {
        private RoleManager<IdentityRole> roleManager { get; set; }
        private readonly UserManager<userIdentity> userManager;
        public RoleController(RoleManager<IdentityRole> roleManager, UserManager<userIdentity> userManager)
        {
            this.roleManager = roleManager;
            this.userManager = userManager;
        }
        public IActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public IActionResult RoleList()
        {
            var roleList = roleManager.Roles.ToList();
            return View(roleList);
        }
        //[Authorize(Policy = "userOpUpDel")]
        [Authorize]
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Create(RoleVm vm)
        {
            IdentityRole identityRole = new IdentityRole
            {
                Name = vm.RoleName
            };
            if (ModelState.IsValid)
            {
                IdentityResult result = await roleManager.CreateAsync(identityRole);
                if (result.Succeeded)
                {
                    return RedirectToAction("RoleList");
                }
                if (result.Errors.Count() > 0)
                {
                    foreach (var s in result.Errors)
                    {
                        ModelState.AddModelError("", s.ToString());
                    }
                }
            }
            return View(identityRole);
        }
        public IActionResult DisplayRoleUser()
        {
            try
            {
                var list = userManager.Users.ToList();
                ViewBag.Userlist = new SelectList(list, "Id", "UserName");
                ViewBag.RoleList = new SelectList(roleManager.Roles, "Name", "Name");
            }
            catch (Exception ex)
            {
                ViewBag.fmessage = "Something went wrong!";
                ViewBag.error = ex.Message;
            }
            return View();
        }
        //public async Task<IActionResult> AssignRole(string Userlist, string RoleList)
        //{
        //    try
        //    {
        //        var list = userManager.Users.ToList();
        //        ViewBag.userList = new SelectList(list, "Id", "UserName");
        //        ViewBag.RoleList = new SelectList(roleManager.Roles, "Name", "Name");
        //        var user = await userManager.FindByIdAsync(Userlist);
        //        IdentityResult result = await userManager.AddToRoleAsync(user, RoleList);
        //        if (result.Succeeded)
        //        {
        //            ViewBag.result = user.UserName + " successfully assigned to role " + RoleList;
        //        }
        //        if (result.Errors.Count() > 0)
        //        {
        //            foreach (var s in result.Errors)
        //            {
        //                ViewBag.fmessage = "Something went wrong!";
        //                ViewBag.error = s.ToString();
        //            };
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ViewBag.fmessage = "Something went wrong!";
        //        ViewBag.error = ex.Message;
        //    }
        //    return View("DisplayRoleuser");
        //}
        [Authorize]
        public async Task<IActionResult> AssignRole(string Userlist, IEnumerable<string> roles)
        {
            try
            {
                var list = userManager.Users.ToList();
                ViewBag.userList = new SelectList(list, "Id", "UserName");
                ViewBag.RoleList = new SelectList(roleManager.Roles, "Name", "Name");
                var user = await userManager.FindByIdAsync(Userlist);
                IdentityResult result = await userManager.AddToRolesAsync(user, roles);
                if (result.Succeeded)
                {
                    ViewBag.result = user.UserName + " successfully assigned to role " + roles;
                }
                if (result.Errors.Count() > 0)
                {
                    foreach (var s in result.Errors)
                    {
                        ViewBag.fmessage = "Something went wrong!";
                        ViewBag.error = s.ToString();
                    };
                }
            }
            catch (Exception ex)
            {
                ViewBag.fmessage = "Something went wrong!";
                ViewBag.error = ex.Message;
            }
            return View("DisplayRoleuser");
        }

        public async Task<IActionResult> ShowRoleNuser()
        {
            List<UserRoleVm> userRoleList = new List<UserRoleVm>();
            var users = userManager.Users.ToList();
            string roleName = "";
            foreach (var u in users)
            {
                UserRoleVm userVM = new UserRoleVm();

                var roles = await userManager.GetRolesAsync(u);
                foreach (var item in roles)
                {
                    roleName = string.Join(",", item);
                }
                userVM.Username = u.UserName;
                userVM.Role = roleName;

                userRoleList.Add(userVM);
            }
            return View(userRoleList);
        }




















        public async Task<IActionResult> AddMultipleRoles(string userList)
        {
            List<string> r = new List<string> { "Admin", "Acct", "MKT" };
            foreach (var s in r)
            {
                if (!await roleManager.RoleExistsAsync(s))
                {
                    await roleManager.CreateAsync(new IdentityRole { Name = s });
                }
            }
            var user = await userManager.FindByIdAsync(userList);
            IdentityResult result = await userManager.AddToRolesAsync(user, r);
            if (result.Succeeded)
            {
                ViewBag.result = "Success";
            }
            return View("DisplayRoleUser");
        }
        //[HttpPost]
        //public async Task<IActionResult> AllRoles()
        //{
        //    var users = userManager.Users.ToList();
        //    string rolename = "";
        //    foreach (var v in users)
        //    {

        //        var roles = await userManager.GetRolesAsync(v);

        //        foreach (var r in roles)
        //        {
        //            rolename = string.Join(",", r);
        //        }

        //    }
        //}
        [HttpGet]
        public async Task<IActionResult> DisplayClaims()
        {
            var ClaimsVm = new ClaimsVm
            {
                Email = ""
            };
            try
            {
                var list = userManager.Users.ToList();
                ViewBag.Userlist = new SelectList(list, "UserName", "UserName");
                var allClaims = ClaimStoreVm.GetClaims;

                var user = await userManager.FindByEmailAsync(ClaimsVm.Email);
                if (user == null)
                {
                    foreach (var c in allClaims)
                    {
                        UserClaimsVm userClaims = new UserClaimsVm
                        {
                            ClaimType = c.Type,
                            IsSelected = false
                        };
                        ClaimsVm.UserClaimsVm.Add(userClaims);
                    }

                }
                else
                {
                    var existingClaim = await userManager.GetClaimsAsync(user);

                    foreach (var c in allClaims)
                    {
                        UserClaimsVm userClaims = new UserClaimsVm
                        {
                            ClaimType = c.Type,
                        };
                        if (existingClaim.Any(a => a.Type == c.Type))
                        {
                            userClaims.IsSelected = true;
                        }
                        ClaimsVm.UserClaimsVm.Add(userClaims);
                    }
                }
            }
            catch (Exception ex)
            {
                ViewBag.Result = ex.Message;
            }
            return View(ClaimsVm);
        }
        [HttpPost]
        public async Task<IActionResult> DisplayClaims(ClaimsVm vm, string Userlist)
        {
            var user = await userManager.FindByEmailAsync(Userlist);
            var existingClaim = await userManager.GetClaimsAsync(user);
            foreach (var c in existingClaim)
            {
                await userManager.RemoveClaimAsync(user, c);
            }
            foreach (var c in vm.UserClaimsVm)
            {
                if (c.IsSelected)
                {
                    IdentityResult result = await userManager.AddClaimAsync(user, new Claim(c.ClaimType, c.ClaimType));
                    if (result.Succeeded)
                    {
                        ViewBag.Result = " Selcted claim on " + vm.Email + " successfully assigned";
                    }
                }
            }
            return View(vm);
        }
    }
}