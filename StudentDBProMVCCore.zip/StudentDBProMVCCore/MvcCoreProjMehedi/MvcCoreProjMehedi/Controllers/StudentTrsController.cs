﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using MvcCoreProjMehedi.Data;
using MvcCoreProjMehedi.Models;

namespace MvcCoreProjMehedi.Controllers
{
    public class StudentTrsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public StudentTrsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: StudentTrs
        public async Task<IActionResult> Index()
        {
            return View(await _context.StudentTrs.ToListAsync());
        }

        // GET: StudentTrs/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var studentTr = await _context.StudentTrs
                .FirstOrDefaultAsync(m => m.LogsId == id);
            if (studentTr == null)
            {
                return NotFound();
            }

            return View(studentTr);
        }
        [Authorize]
        // POST: StudentTrs/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var studentTr = await _context.StudentTrs.FindAsync(id);
            _context.StudentTrs.Remove(studentTr);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool StudentTrExists(int id)
        {
            return _context.StudentTrs.Any(e => e.LogsId == id);
        }
    }
}
