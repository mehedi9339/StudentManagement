﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using MvcCoreProjMehedi.Data;
using MvcCoreProjMehedi.Models;
using MvcCoreProjMehedi.ViewModels;

namespace MvcCoreProjMehedi.Controllers
{
    public class ClassTblsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ClassTblsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: ClassTbls
        public async Task<IActionResult> Index()
        {
            //var viewModel = new StudentIndexData();
            //viewModel.ClassTbls = await _context.ClassTbls
            //    .Include(i => i.StudentTbls)
            //                .ThenInclude(i => i.ClassTbl)
            //      .AsNoTracking()
            //      .OrderBy(i => i.ClassName)
            //      .ToListAsync();

            //if (id != null)
            //{
            //    ViewData["ClassId"] = id.Value;
            //    ClassTbl classTbl = viewModel.ClassTbls.Where(
            //        i => i.ClassId == id.Value).Single();
            //    viewModel.StudentTbls = classTbl.Select(s => s.Student);
            //}

            return View(await _context.ClassTbls.ToListAsync());
        }

        //GET: Category Wise Student (Partial View)
        public IActionResult GetAll()
        {
            ViewBag.ClsId = new SelectList(_context.ClassTbls.ToList(), "ClassId", "ClassName");
            ViewBag.SecId = new SelectList(_context.SectionTbls.ToList(), "SecId", "SectionName");
            List<ClsStuVm> data = new List<ClsStuVm>();
            foreach (ClassTbl classTbl in _context.ClassTbls)
            {
                data.Add(new ClsStuVm
                {
                    ClassName = classTbl.ClassName,
                    RoomNo = classTbl.RoomNo,
                    StudentTbls = _context.StudentTbls.Where(p => p.ClassId == classTbl.ClassId).ToList()
                });
            }
            return View(data);
        }
        [Authorize]
        public IActionResult Update(IFormCollection data)
        {
            StudentTbl s = new StudentTbl
            {
                StudentName = data["txtName"],
                GuardianPhone = data["txtPhone"],
                DateOfBirth = data["txtDOB"],
                Address = data["txtAddress"],
                Height = Int32.Parse(data["txtHeight"]),
                Photo = data["txtPhoto"],
                ClassId = Int32.Parse(data["txtCls"]),
                SecId = Int32.Parse(data["txtSec"]),
                StudentId = Int32.Parse(data["txtId"])
            };
            _context.Entry(s).State = EntityState.Modified;
            if (_context.SaveChanges() > 0)
            {
                return RedirectToAction("GetAll");
            }
            return View(s);
        }

        // GET: ClassTbls/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var classTbl = await _context.ClassTbls
                .FirstOrDefaultAsync(m => m.ClassId == id);
            if (classTbl == null)
            {
                return NotFound();
            }

            return View(classTbl);
        }

        // GET: ClassTbls/Create
        //public IActionResult Create()
        //{
        //    return View();
        //}

        //// POST: ClassTbls/Create
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public async Task<IActionResult> Create([Bind("ClassId,ClassName,RoomNo")] ClassTbl classTbl)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        _context.Add(classTbl);
        //        await _context.SaveChangesAsync();
        //        return RedirectToAction(nameof(Index));
        //    }
        //    return View(classTbl);
        //}
        [Authorize]
        public IActionResult Create2()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create2(ClassTbl classTbl)
        {
            var proc = _context.Database.ExecuteSqlCommand("exec sp_createClass @ClassName = {0}, @RoomNo= {1}", classTbl.ClassName, classTbl.RoomNo);
            if (proc > 0)
            {
                return RedirectToAction("Index");
            }
            return View(classTbl);
        }


        [HttpPost]
        public IActionResult CreateMulti(List<ClassTbl> classTbls)
        {
            if (classTbls.Count > 0)
            {
                _context.AddRange(classTbls);
                if (_context.SaveChanges() > 0)
                {
                    return RedirectToAction("Index");
                }

            }
            return View(classTbls);
        }
        [Authorize]
        // GET: ClassTbls/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var classTbl = await _context.ClassTbls.FindAsync(id);
            if (classTbl == null)
            {
                return NotFound();
            }
            return View(classTbl);
        }

        // POST: ClassTbls/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ClassId,ClassName,RoomNo")] ClassTbl classTbl)
        {
            if (id != classTbl.ClassId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(classTbl);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ClassTblExists(classTbl.ClassId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(classTbl);
        }
        [Authorize]
        // GET: ClassTbls/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var classTbl = await _context.ClassTbls
                .FirstOrDefaultAsync(m => m.ClassId == id);
            if (classTbl == null)
            {
                return NotFound();
            }

            return View(classTbl);
        }

        // POST: ClassTbls/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var classTbl = await _context.ClassTbls.FindAsync(id);
            _context.ClassTbls.Remove(classTbl);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ClassTblExists(int id)
        {
            return _context.ClassTbls.Any(e => e.ClassId == id);
        }
    }
}
