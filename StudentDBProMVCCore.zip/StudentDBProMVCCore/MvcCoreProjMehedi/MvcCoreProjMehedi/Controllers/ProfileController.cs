﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using MvcCoreProjMehedi.Models.Identity;
using MvcCoreProjMehedi.ViewModels;

namespace MvcCoreProjMehedi.Controllers
{
    public class ProfileController : Controller
    {
        private UserManager<userIdentity> userManager;
        private readonly IHostingEnvironment hosting;
        public ProfileController(UserManager<userIdentity> user, IHostingEnvironment hosting)
        {
            this.userManager = user;
            this.hosting = hosting;
        }
        [Authorize]
        [HttpGet]
        public IActionResult Index()
        {
            var users = userManager.Users;
            //var user = await userManager.FindByIdAsync(userId);
            return View(users);
        }
        [HttpGet]
        public async Task<IActionResult> Edit(string id)
        {
            var user = await userManager.FindByIdAsync(id);
            if (user == null)
            {
                ViewBag.ErrorMessage = $"User with Id = {id} cannot be found";
                return View("NotFound");
            }
            var model = new ProfileVm
            {
                Id = user.Id,
                UserName = user.UserName,
                PhoneNumber = user.PhoneNumber,
                Email = user.Email,
                FirstName = user.FirstName,
                LastName = user.LastName,
                DateOfBirth = user.DateOfBirth,
                Photo = user.Photo
            };
            return View(model);
        }
        [HttpPost]
        public async Task<IActionResult> Edit(ProfileVm vm)
        {
            var user = await userManager.FindByIdAsync(vm.Id);
            if (user == null)
            {
                ViewBag.ErrorMessage = $"User with Id = {vm.Id} cannot be found";
                return View("NotFound");
            }
            else
            {
                if (vm.imgFile != null)
                {
                    string ext = Path.GetExtension(vm.imgFile.FileName).ToLower();
                    if (ext == ".jpg" || ext == ".png" || ext == ".jpeg")
                    {
                        var filename = Path.GetFileName(vm.imgFile.FileName);
                        var filePath = Path.Combine(hosting.WebRootPath, "images\\ProfilePic", filename);
                        using (var fileStream = new FileStream(filePath, FileMode.Create))
                        {
                            vm.imgFile.CopyTo(fileStream);
                            user.Photo = "\\images\\ProfilePic\\" + vm.imgFile.FileName;
                        }
                    }
                }
                user.FirstName = vm.FirstName;
                user.LastName = vm.LastName;
                user.PhoneNumber = vm.PhoneNumber;
                user.DateOfBirth = vm.DateOfBirth;
                user.Email = vm.Email;
            }
            var result = await userManager.UpdateAsync(user);

            if (result.Succeeded)
            {
                return RedirectToAction("Index");
            }
            else
            {
                foreach (var item in result.Errors)
                {
                    ViewBag.sResult = item.Description;
                }
            }
            return View(vm);
        }
    }
}