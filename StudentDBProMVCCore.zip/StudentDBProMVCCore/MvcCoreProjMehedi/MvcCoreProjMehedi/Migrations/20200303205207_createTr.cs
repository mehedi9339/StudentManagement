﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace MvcCoreProjMehedi.Migrations
{
    public partial class createTr : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"Create TRIGGER tr_StudentUpdate
                            ON StudentTbls
                            AFTER UPDATE
                            AS
                            BEGIN
                            SET NOCOUNT ON;
                            DECLARE @StudentId INT
	                        DECLARE @PrevClassId INT
	                        DECLARE @StudentName nvarchar(max)
	                        declare @prevSecId int
	                        declare @preSecId int
	                        DECLARE @PreClassId INT
                            DECLARE @Action VARCHAR(200)
 
                            SELECT @StudentId = INSERTED.StudentId, @PreClassId = inserted.ClassId, @preSecId = inserted.SecId
                            FROM INSERTED
	                        Select @PrevClassId = deleted.ClassId, @StudentName = deleted.StudentName, @prevSecId = deleted.SecId
	                        FROM deleted
 
                            IF UPDATE(ClassId)
                            BEGIN
                                    SET @Action = 'Updated Information'
                            END
	                        IF UPDATE(SecId)
                            BEGIN
                                    SET @Action = 'Updated Information'
                            END
 
                            INSERT INTO StudentTrs
                            VALUES(@StudentId,@StudentName, @PrevClassId,@PreClassId, @prevSecId, @preSecId, @Action)
                    END");

            migrationBuilder.CreateTable(
                name: "StudentTrs",
                columns: table => new
                {
                    LogsId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    StudentId = table.Column<int>(nullable: false),
                    StudentName = table.Column<string>(nullable: true),
                    PrevClass = table.Column<int>(nullable: false),
                    PreClass = table.Column<int>(nullable: false),
                    PrevSec = table.Column<int>(nullable: false),
                    PreSec = table.Column<int>(nullable: false),
                    Action = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_StudentTrs", x => x.LogsId);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "StudentTrs");
        }
    }
}
