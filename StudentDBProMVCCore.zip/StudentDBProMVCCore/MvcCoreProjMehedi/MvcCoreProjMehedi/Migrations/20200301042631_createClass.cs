﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace MvcCoreProjMehedi.Migrations
{
    public partial class createClass : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"Create PROC sp_createClass
                                    @ClassName NVARCHAR(MAX), @RoomNo INT
                                    AS
                                    BEGIN
                                    insert into ClassTbls values (@ClassName, @RoomNo)
                                    END");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
