﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using MvcCoreProjMehedi.Models;
using MvcCoreProjMehedi.Models.Identity;
using MvcCoreProjMehedi.ViewModels;

namespace MvcCoreProjMehedi.Data
{
    public class ApplicationDbContext : IdentityDbContext<userIdentity>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {

        }
        public DbSet<RoleVm> RoleVm { get; set; }
        public DbSet<UserRoleVm> UserRoleVm { get; set; }
        public DbSet<TeacherTbl> TeacherTbls { get; set; }
        public DbSet<StudentTbl> StudentTbls { get; set; }
        public DbSet<ClassTbl> ClassTbls { get; set; }
        public DbSet<SectionTbl> SectionTbls { get; set; }
        public DbSet<StudentTr> StudentTrs { get; set; }



        //public DbSet<StudentAssignment> StudentAssignments { get; set; }
        //protected override void OnModelCreating(ModelBuilder modelBuilder)
        //{
        //    modelBuilder.Entity<RoleVm>().ToTable("RoleVm");
        //    modelBuilder.Entity<UserRoleVm>().ToTable("UserRoleVm");
        //    modelBuilder.Entity<TeacherTbl>().ToTable("TeacherTbls");
        //    modelBuilder.Entity<StudentTbl>().ToTable("StudentTbls");
        //    modelBuilder.Entity<ClassTbl>().ToTable("ClassTbls");
        //    modelBuilder.Entity<SectionTbl>().ToTable("SectionTbls");
        //    modelBuilder.Entity<StudentAssignment>().ToTable("StudentAssignments");

        //    modelBuilder.Entity<StudentAssignment>()
        //        .HasKey(c => new { c.StudentId, c.ClassId });
        //}
    }
}
