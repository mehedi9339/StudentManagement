﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace MvcCoreProjMehedi.Models
{
    public class ClassTbl
    {
        [Key]
        public int ClassId { get; set; }
        [DisplayName("Class")]
        public string ClassName { get; set; }
        [DisplayName("Room No.")]
        public int RoomNo { get; set; }

        public ICollection<StudentTbl> StudentTbls { get; set; }
        public ICollection<TeacherTbl> TeacherTbls { get; set; }



        //public ICollection<StudentAssignment> StudentAssignments { get; set; }
    }
}
