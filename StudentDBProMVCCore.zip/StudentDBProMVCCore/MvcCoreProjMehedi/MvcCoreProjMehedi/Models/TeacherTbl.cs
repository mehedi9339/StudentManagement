﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace MvcCoreProjMehedi.Models
{
    public class TeacherTbl
    {
        [Key]
        public int TeacherId { get; set; }
        [DisplayName("Teacher Name")]
        public string TeacherName { get; set; }
        [DisplayName("Teacher Address")]
        public string TeacherAddress { get; set; }
        [DisplayName("Teacher Phone")]
        public string TeacherPhone { get; set; }
        [DisplayName("Teacher Email")]
        public string TeacherEmail { get; set; }
        [DisplayName("Joining Date")]
        public DateTime JoiningDate { get; set; }
        [DisplayName("Section"), ForeignKey("SectionTbl")]
        public int SecId { get; set; }
        [DisplayName("Class"), ForeignKey("ClassTbl")]
        public int ClassId { get; set; }
        [DisplayName("Teacher Photo")]
        public string Photo { get; set; }

        //[NotMapped]
        //public IFormFile ImgFile { get; set; }

        public virtual SectionTbl SectionTbl { get; set; }
        public virtual ClassTbl ClassTbl { get; set; }
    }
}
