﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MvcCoreProjMehedi.Models
{
    public class StudentIndexData
    {
        public IEnumerable<StudentTbl> StudentTbls { get; set; }
        public IEnumerable<ClassTbl> ClassTbls { get; set; }
    }
}
