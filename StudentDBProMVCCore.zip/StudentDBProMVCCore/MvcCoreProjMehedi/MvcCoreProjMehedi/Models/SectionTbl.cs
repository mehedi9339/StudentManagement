﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace MvcCoreProjMehedi.Models
{
    public class SectionTbl
    {
        [Key]
        public int SecId { get; set; }
        [DisplayName("Section")]
        public string SectionName { get; set; }
        [DisplayName("Description")]
        public string Description { get; set; }

        public ICollection<StudentTbl> StudentTbls { get; set; }
        public ICollection<TeacherTbl> TeacherTbls { get; set; }
    }
}
