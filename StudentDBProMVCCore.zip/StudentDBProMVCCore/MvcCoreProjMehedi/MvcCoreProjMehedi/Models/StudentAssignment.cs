﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MvcCoreProjMehedi.Models
{
    public class StudentAssignment
    {
        public int ClassId { get; set; }
        public int StudentId { get; set; }
        public ClassTbl ClassTbl { get; set; }
        public StudentTbl StudentTbl { get; set; }
    }
}
