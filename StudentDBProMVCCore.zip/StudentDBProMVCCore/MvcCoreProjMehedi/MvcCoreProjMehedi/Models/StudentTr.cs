﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace MvcCoreProjMehedi.Models
{
    public class StudentTr
    {
        [Key]
        public int LogsId { get; set; }
        public int StudentId { get; set; }
        public string StudentName { get; set; }
        [DisplayName("Previous Class")]
        public int PrevClass { get; set; }
        [DisplayName("Present Class")]
        public int PreClass { get; set; }
        [DisplayName("Previous Section")]
        public int PrevSec { get; set; }
        [DisplayName("Precsent Section")]
        public int PreSec { get; set; }
        public string Action { get; set; }
    }
}
