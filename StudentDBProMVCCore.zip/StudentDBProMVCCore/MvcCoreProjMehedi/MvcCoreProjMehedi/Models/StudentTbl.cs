﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace MvcCoreProjMehedi.Models
{
    public class StudentTbl
    {
        [Key]
        public int StudentId { get; set; }
        [DisplayName("Student Name")]
        public string StudentName { get; set; }
        [DisplayName("Student Phone")]
        public string GuardianPhone { get; set; }
        [DisplayName("Date Of Birth")]
        public string DateOfBirth { get; set; }
        [DisplayName("Student Address")]
        public string Address { get; set; }
        [DisplayName("Student Height (cm)")]
        public int Height { get; set; }
        [DisplayName("Section"), ForeignKey("SectionTbl")]
        public int SecId { get; set; }
        [DisplayName("Class"), ForeignKey("ClassTbl")]
        public int ClassId { get; set; }
        public int Year { get; set; }
        [DisplayName("Student Enrollment")]
        public DateTime EnrollmentDate { get; set; }
        [DisplayName("Student Photo")]
        public string Photo { get; set; }

        [NotMapped]
        public IFormFile ImgFile { get; set; }

        public virtual SectionTbl SectionTbl { get; set; }
        public virtual ClassTbl ClassTbl { get; set; }




        //public ICollection<StudentAssignment> StudentAssignments { get; set; }
    }
}
